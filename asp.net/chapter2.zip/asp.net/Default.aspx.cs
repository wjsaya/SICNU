﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        dd_age.Items.Clear();
        dd_age.Items.Add(new ListItem("显示内容", "传递到后台的值"));
        /*
        ListItem[] items1 = {
            new ListItem("1", "1"),
            new ListItem("2", "2")
        };  创建列表
        dd_age.Items.AddRange(items1);  添加列表
        */
        for (int i = 15; i <= 99; i++)
        {
            dd_age.Items.Add(new ListItem(i.ToString() + " 岁", i.ToString()));
        }
        dd_age.Items.RemoveAt(0);   //  Index(0-->XXX)
    }



    protected void subbmit(object sender, EventArgs e)
    {
        String gender = "未选择";
        if (rb_man.Checked) gender = "男";
        if (rb_woman.Checked) gender = "女";
        
        /*
        string scriptstrs = "<script>alert('";
        scriptstrs += "你的" + "名字" + "是\\t" + tb_name.Text + "\\n";
        scriptstrs += "你的" + "性别" + "是\\t" + gender + "\\n";
        scriptstrs += "你的" + "身份证号" + "是\\t" + tb_idno.Text + "\\n";
        scriptstrs += "你的" + "年龄" + "是\\t" + dd_age.Items[dd_age.SelectedIndex].Text + "\\n";
        scriptstrs += "你的" + "现居住地" + "是\\t" + tb_place.Text + "\\n";
        scriptstrs += "你的" + "职业" + "是\\t" + tb_profession.Text + "\\n";
        scriptstrs += "你的" + "腾讯微博账号" + "是\\t" + tb_weibo.Text + "\\n";
        scriptstrs += "你的" + "联系电话" + "是\\t" + tb_tel.Text + "\\n";
        scriptstrs  += "');</script>";
        
        if (!Page.ClientScript.IsStartupScriptRegistered(this.GetType(), "Hint"))
        {
            Page.ClientScript.RegisterStartupScript(this.GetType(), "Hint", scriptstrs);
        }
        */
        lb_Hint.Text = "已提交";

        //        Response.Redirect("./newPage.aspx?hint=default.aspx");
        Session["name"] = tb_name.Text;
        Session["gender"] = gender;
        Session["idno"] = tb_idno.Text;
        Session["place"] = tb_place.Text;
        Session["age"] = dd_age.Items[dd_age.SelectedIndex].Text;
        Session["profession"] = tb_profession.Text;
        Session["weibo"] = tb_weibo.Text;
        Session["tel"] = tb_tel.Text;
        Response.Redirect("./newPage.aspx?hint=default.aspx");
        
    }



}