﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class newPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        toReplace.Text = Request.QueryString["hint"];
        Label1.Text = Session["name"].ToString();
        Label2.Text = Session["gender"].ToString();
        Label3.Text = Session["idno"].ToString();
        Label4.Text = Session["place"].ToString();
        Label5.Text = Session["age"].ToString();
        Label6.Text = Session["profession"].ToString();
        Label7.Text = Session["weibo"].ToString();
        Label8.Text = Session["tel"].ToString();
    }
}