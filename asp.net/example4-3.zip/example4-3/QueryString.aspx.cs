﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class QueryString : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = Request.QueryString["username"];
        string age = Request.QueryString["userage"];
        string role = Request.QueryString["userrole"];
        lbinfo.Text = "姓名：" + name + "<br>年龄：" + age + "<br>角色：" + role;
    }
}