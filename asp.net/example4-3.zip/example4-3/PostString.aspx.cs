﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PostString : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name = Request.Form["name"];
        string pass = Request.Form["pass"];
        string realname = Request.Form["realname"];
        string phoneNO = Request.Form["phoneNO"];

        lbinfo.Text = "姓名：" + name + "<br>密码：" + pass + "<br>真实姓名：" + realname + "<br>电话号码：" + phoneNO;

    }
}