﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
///UserInfo 的摘要说明
/// </summary>
public class UserInfo
{
    public String UserName;
    public String UserPass;

    public UserInfo()
    {

    }
}
