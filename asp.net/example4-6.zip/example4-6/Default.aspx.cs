﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }    

    protected void btnVote_Click(object sender, EventArgs e)
    {
        string userip = Request.UserHostAddress.ToString();
        HttpCookie hcCookie = Request.Cookies["UserIP"];

        if (hcCookie == null)
        {
            HttpCookie newCookie = new HttpCookie("UserIP");
            newCookie.Expires = DateTime.Now.AddSeconds(10);
            newCookie.Values.Add("UserAddressIP", userip);
            Response.AppendCookie(newCookie);
            Page.ClientScript.RegisterStartupScript(GetType(), "",
                "<script>alert('投票成功~')</script>");
            return;
        }
        else
        {
            string oldip = hcCookie.Values[0];
            if (userip.Trim() == oldip.Trim())
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "",
                    "<script>alert('已经投过了，10秒后再试~')</script>");
                return;
            }
            else
            {
                HttpCookie newCookie = new HttpCookie("UserIP");
                newCookie.Expires = DateTime.Now.AddSeconds(10);
                newCookie.Values.Add("UserAddressIP", userip);
                Response.AppendCookie(newCookie);
                Page.ClientScript.RegisterStartupScript(GetType(), "",
                    "<script>alert('投票成功~')</script>");
                return;
            }
        }
    }
}