﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class userInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.PreviousPage != null)
        {
            if (PreviousPage.IsCrossPagePostBack)
            {
                lb_username.Text = ((TextBox)this.PreviousPage.FindControl("tb_username")).Text;
                lb_password.Text = ((TextBox)this.PreviousPage.FindControl("tb_password")).Text;
                lb_gender.Text = ((RadioButtonList)this.PreviousPage.FindControl("rbl_gender")).Text;
                lb_profess.Text = ((RadioButtonList)this.PreviousPage.FindControl("rbl_profess")).Text;
                lb_where.Text = ((DropDownList)this.PreviousPage.FindControl("ddl_where")).Text;
//                ig_avator.u FileUpload
                string picurl = ((FileUpload)this.PreviousPage.FindControl("fu_avator")).PostedFile.FileName;
                ig_avator.ImageUrl = "~/upload/" + picurl;
            }
        }
    }

     protected void temp() {
        String name;

        HttpCookie newCookie = Request.Cookies["info"];

        if (newCookie != null)
        {
            name = newCookie.Values["username"];
            Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert(|||||'" + name + "|||||')</script>");
            lb_username.Text = newCookie.Values["username"];
        }
        else
        {
            Page.ClientScript.RegisterStartupScript(GetType(), "", "<script>alert('cookie为空')</script>");
        }
    }
}
        /*
        lb_username.Text = "asdasdasd";
        if (Session["username"] != null)
        {
            lb_username.Text = Session["username"].ToString();
        }

        if (Session["password"] != null)
        {
            lb_password.Text = Session["password"].ToString();
        }

        if (Session["gender"] != null)
        {
            lb_gender.Text = Session["gender"].ToString(); ;
        }

        if (Session["profess"] != null)
        {
            lb_profess.Text = Session["profess"].ToString();
        }

        if (Session["where"] != null)
        {
            lb_where.Text = Session["where"].ToString();
        }
         */
   