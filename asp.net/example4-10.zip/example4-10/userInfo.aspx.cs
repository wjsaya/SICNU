﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class userInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["username"] != null)
        {
            lb_username.Text = Session["username"].ToString();
        }
        if (Session["password"] != null)
        {
            lb_password.Text = Session["password"].ToString();
        }
        if (Session["gender"] != null)
        {
            lb_gender.Text = Session["gender"].ToString(); ;
        }
        if (Session["profess"] != null)
        {
            lb_profess.Text = Session["profess"].ToString();
        }
        if (Session["where"] != null)
        {
            lb_where.Text = Session["where"].ToString();
        }
    }
}