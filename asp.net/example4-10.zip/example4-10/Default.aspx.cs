﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void bu_subbmit_Click(object sender, EventArgs e)
    {
        if (tb_username.Text != null)
            Session["username"] = tb_username.Text;
        if (tb_password.Text != null)
            Session["password"] = tb_password.Text;
        if (tb_passCheck.Text != null)
            Session["username"] = tb_passCheck.Text;

        if (rb_female.Checked)
            Session["gender"] = rb_female.Text;
        else if (rb_male.Checked)
            Session["gender"] = rb_male.Text;

        Session["profess"] = rbl_profess.SelectedValue;

        Session["where"] = ddl_where.SelectedValue;
        Response.Redirect("userInfo.aspx", true); 
    }
}