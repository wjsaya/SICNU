﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class regist : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void bu_submit_Click(object sender, EventArgs e)
    {
        string connectString = "Data Source=.;Initial Catalog=testdb;User ID=sa;Pwd=123qwe";
        SqlConnection conn = new SqlConnection(connectString);

        string sqli = "INSERT INTO student VALUES('" + tb_id.Text + "', '" + tb_name.Text + "', '" + tb_age.Text + "');";

        conn.Open();
        SqlCommand command = new SqlCommand();
        command.CommandText = sqli;
        command.CommandType = System.Data.CommandType.Text;
        command.Connection = conn;

        int result = command.ExecuteNonQuery();
        if (result > 0)
        {
            lb_notice.Text = "7-3成功插入";
        }
        else
        {
            lb_notice.Text = "7-3插入失败";
        }
    }
}