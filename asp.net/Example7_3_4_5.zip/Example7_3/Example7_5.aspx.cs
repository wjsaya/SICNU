﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Example7_5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string connectString = "Data Source=.;Initial Catalog=testdb;User ID=sa;Pwd=123qwe";
        SqlConnection conn = new SqlConnection(connectString);

        string sqli = "SELECT count(1) FROM student;";

        conn.Open();
        SqlCommand command = new SqlCommand(sqli, conn);
        command.CommandType = System.Data.CommandType.Text;
        
        int result = Convert.ToInt32(command.ExecuteScalar());
        lb_info.Text = "已有" + result + "条记录";
    }
}