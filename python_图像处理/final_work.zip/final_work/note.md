# 变量说明
## main.py
变量|说明|格式
---|---|---
self.fileName|调用QFileDialog打开文件，存放文件名|列表(0为文件名，1为打开图片时选择的格式)
self.__no_scaled_origin_pixmap|存放原图的原始、未经缩放的pixmap|pixmap
self.__no_scaled_big_prev_pixmap|存放大预览图的原始、未缩放pixmap|pixmap
self.big_prev_pixmap|临时变量，用来对大预览图进行缩放|pixmap
self.big_prev_scaled|被缩放之后的大预览图|pixmap
self.thumb_prev_pixmap|被修改后的大预览图，供thumb_prev使用|pixmap
self.saveimg_name|保存图片的文件名|filename
变量|变量说明


## ui文件.py
变量|说明|格式
---|---|---
self.thumb_origin|原图缩略图|Qlabel
self.thumb_prev|修改后缩略图|Qlabel
self.statusBar|程序页面下方提示栏|statusBar
变量|变量说明
变量|变量说明

# 方法说明
## main.py
方法名|in|out|功能
---|---|---|---
self.on_button_open_clicked|self|None|打开图片并展示到big_prev以及一些初始化
self.on_button_save_clicked|self|None|保存big_prev的图片到磁盘
wheelEvent|self, event|None|重写鼠标滚轮事件,实现ctrl+滚轮缩放图片
closeEvent|self, event|None|重写关闭事件,添加确认弹框
