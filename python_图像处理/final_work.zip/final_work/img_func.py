#!/usr/bin/env python  
#-*- coding: utf-8 -*-  
  
import cv2
import numpy

from PIL import Image
from PIL.ImageQt import ImageQt
from PyQt5 import QtGui

class img_operate():
    def __init__(self, parent=None):
        pass

    def otsu_im(imgin):
        img = numpy.asarray(imgin)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        retval, dst = cv2.threshold(gray, 0, 255, cv2.THRESH_OTSU)
        img = Image.fromarray(dst)  #二值图转回PIL格式
        img = QtGui.QPixmap.fromImage(img)
        return ImageQt(img)
    
    def JX(imgin, type):
        if type == 's':
            out = imgin.transpose(Image.FLIP_TOP_BOTTOM) 
        elif type == 'v':
            out = imgin.transpose(Image.FLIP_LEFT_RIGHT)
        imgout = out.convert('RGBA')  #二值图转回PIL格式
        imgout = QtGui.QPixmap.fromImage(ImageQt(imgout))
        return imgout
        
    def jyzs(imgin):    #椒盐噪声
        img = numpy.asarray(imgin)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        retval, dst = cv2.threshold(gray, 0, 255, cv2.THRESH_OTSU)
        img = Image.fromarray(dst)  #二值图转回PIL格式
        img = QtGui.QPixmap.fromImage(img)
        return ImageQt(img)
    


