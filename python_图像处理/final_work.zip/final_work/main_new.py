# -*- coding: utf-8 -*-
import os
import sys

from PIL import Image
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import pyqtSlot

from Ui_temp_update import Ui_MainWindow

from PIL import Image
from PIL.ImageQt import ImageQt

from img_func import img_operate

class MainWindow(QtWidgets.QMainWindow,  Ui_MainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.setWindowIcon(QtGui.QIcon('./icons/mainWindow.jpg'))
        self.action_quit.triggered.connect(self.close)
#        self.JHBH_widget.hide() #隐藏几何变换的一对button
        
    def wheelEvent(self, event):
        if self.big_prev.pixmap() is None:  #big_prev无内容，无视滚轮
            print("None")
            return

        modifiers = QtWidgets.QApplication.keyboardModifiers()
        if modifiers != QtCore.Qt.ControlModifier:  #未按着ctrl滚轮，无视
            print('Ctrl 未按下')
            return

        self.delta = event.angleDelta().y()
        if self.big_prev.underMouse():   #big_prev是否在鼠标下面
            big_prev_height = self.big_prev.height()
            big_prev_width = self.big_prev.width()
            self.big_prev_pixmap = self.__no_scaled_big_prev_pixmap.copy()
            if(self.delta > 0):
                self.big_prev_scaled = self.big_prev_pixmap.scaled(big_prev_width*1.1, big_prev_height*1.1, aspectRatioMode=QtCore.Qt.KeepAspectRatio) 
                self.big_prev.setPixmap(self.big_prev_scaled)
                self.statusBar().showMessage("当前图片尺寸：" + str(big_prev_width) + ' X ' + str(big_prev_height))
            else:
                self.big_prev_scaled = self.big_prev_pixmap.scaled(big_prev_width*0.9, big_prev_height*0.9, aspectRatioMode=QtCore.Qt.KeepAspectRatio) 
                self.big_prev.setPixmap(self.big_prev_scaled)
                self.statusBar().showMessage("当前图片尺寸：" + str(big_prev_width) + ' X ' + str(big_prev_height))
        

    def closeEvent(self, event): 
        #重写closeEvent,添加确认弹框
        if (isinstance(self.thumb_prev.pixmap(), QtGui.QPixmap)) is False:
            #sys.exit() 
            # 如果不用if嵌套,直接sys.exit()也可,但是if嵌套逻辑更清晰.
            # 如果self.img_prev.pixmap()不是Qpixmap,那么img_prev标签则没有图片,那么直接同意closeEvent退出即可.
            event.accept()
        else:
            checkMsgBox = QtWidgets.QMessageBox(self) 
            checkMsgBox.setWindowTitle("退出?") 
            checkMsgBox.setWindowIcon(QtGui.QIcon('./icons/quit.ico'))
            savequitButton = checkMsgBox.addButton(self.tr("保存&退出"), QtWidgets.QMessageBox.ActionRole)
            justquitButton = checkMsgBox.addButton(self.tr("直接退出"), QtWidgets.QMessageBox.ActionRole)
            cancelButton = checkMsgBox.addButton("手滑了,取消",QtWidgets.QMessageBox.ActionRole)
            checkMsgBox.setText(self.tr("对图片的修改还未保存,直接退出?"))
            checkMsgBox.exec_()
        
            button = checkMsgBox.clickedButton()
            if button == savequitButton:
                self.on_button_save_clicked()
                event.accept()
            elif button == justquitButton:
                event.accept()
            elif button == cancelButton:
                event.ignore()


    def put_thumb_prev(self, label_name):
        if label_name == 'thumb_origin':
            self.thumb_temp_pixmap = self.__no_scaled_origin_pixmap.copy()
            self.thumb_origin.setPixmap(self.thumb_temp_pixmap.scaled(self.thumb_origin.size(), aspectRatioMode=QtCore.Qt.KeepAspectRatio))
            print("origin已更改")
        elif label_name == 'thumb_prev':
            self.thumb_temp_pixmap = self.__no_scaled_big_prev_pixmap.copy()
            self.thumb_prev.setPixmap(self.thumb_temp_pixmap.scaled(self.thumb_prev.size(), aspectRatioMode=QtCore.Qt.KeepAspectRatio))
            print("prev已更改")


    @pyqtSlot()
    def on_action_about_triggered(self): 
        self.statusBar().showMessage('关于我们')   ###############################################################3
        QtWidgets.QMessageBox.information(None, "关于我们",
            "第X组\n")
    

    @pyqtSlot()
    def on_action_open_triggered(self):
        self.fileName = QtWidgets.QFileDialog.getOpenFileName(self,
		    "选择想要编辑的图片",
		    "./",
		    "常见图片格式(*.jpeg *.jpg *.png *.bmp) ;; 所有文件 (*)")
        print(self.fileName)
        self.statusBar().showMessage("已打开:" + self.fileName[0])
        self.__no_scaled_origin_pixmap = QtGui.QPixmap(self.fileName[0])
        self.__no_scaled_big_prev_pixmap = self.__no_scaled_origin_pixmap.copy()   
        self.big_prev.setPixmap(self.__no_scaled_origin_pixmap)
        self.put_thumb_prev(label_name='thumb_origin')

    @pyqtSlot()
    def on_action_save_triggered(self):     
        QtWidgets.QMessageBox.information(None, "提示",
            "保存图片为右边预览窗口的图片,包括图片大小都是\n"
            "建议将图片缩放到所需尺寸后再保存\n")
        self.saveimg_name, self.saveimg_type = QtWidgets.QFileDialog.getSaveFileName(self,  
            "文件保存",
            "./",
            "Image files(*.jpeg *.jpg *.png *.bmp) ;; 所有文件 (*)")

        if self.saveimg_name != '':
            try:
                self.big_prev.pixmap().save(self.saveimg_name)
                self.statusBar().showMessage("已保存为:" + self.saveimg_name)
            except:
                self.statusBar().showMessage("保存失败")

    @pyqtSlot()
    def on_action_2gray_triggered(self):
        img = Image.fromqpixmap(self.big_prev.pixmap()).convert('L')
        img = QtGui.QPixmap.fromImage(ImageQt(img))
        self.big_prev.setPixmap(img)
        self.__no_scaled_big_prev_pixmap = img.copy()
        self.put_thumb_prev(label_name='thumb_prev')


    @pyqtSlot()
    def on_action_2binary_triggered(self):
        img = Image.fromqpixmap(self.big_prev.pixmap())
        img = img_operate.otsu_im(img)
        self.big_prev.setPixmap(img)
        self.__no_scaled_big_prev_pixmap = img.copy()
        self.put_thumb_prev(label_name='thumb_prev')


    @pyqtSlot()
    def on_JX_v_clicked(self):
        img = Image.fromqpixmap(self.big_prev.pixmap())
        img = img_operate.JX(img, type='v')
        self.big_prev.setPixmap(img)

    @pyqtSlot()
    def on_JX_s_clicked(self):
        img = Image.fromqpixmap(self.big_prev.pixmap())
        img = img_operate.JX(img, type='s')
        self.big_prev.setPixmap(img)

    
    def on_slider_XZ_valueChanged(self):
    #未做要求，不再继续完善
        if 'originXZOrigin' not in dir(self):
            self.originXZOrigin = self.big_prev.pixmap().copy()    #保存预览图最初样貌,scaled会调用
            self.prevXZ2Origin = self.originXZOrigin.copy()
        else:
            self.originXZOrigin = self.prevXZ2Origin.copy()

        value_now = self.slider_XZ.value() * 3.6
        pixmap = Image.fromqpixmap(self.originXZOrigin)
        pixmap = pixmap.rotate(value_now) #两
        QtImage1 = ImageQt(pixmap.convert('RGBA'))
        pixmap = QtGui.QPixmap.fromImage(QtImage1)
        self.big_prev.setPixmap(pixmap)
        self.__no_scaled_big_prev_pixmap = pixmap.copy()
        self.put_thumb_prev(label_name='thumb_prev')
       ##有问题部分


        

if __name__ == "__main__":
    app=0
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())
