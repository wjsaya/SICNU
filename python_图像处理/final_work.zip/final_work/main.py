# -*- coding: utf-8 -*-
'''
TODO List:
旋转，没有绕坐标原点
当前缩放有问题，待后续更改为ctrl+滚轮缩放
均值滤波等。。。
'''

from PyQt5.QtCore import pyqtSlot
from PyQt5 import QtGui
import sys
from PyQt5 import QtWidgets
from PyQt5 import QtCore

from Ui_temp_update import Ui_MainWindow

from PIL import Image, ImageChops
from PIL.ImageQt import ImageQt

import os

class MainWindow(QtWidgets.QMainWindow,  Ui_MainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.setWindowIcon(QtGui.QIcon('./icons/mainWindow.jpg'))
        self.action_open.triggered.connect(self.on_button_open_clicked)
        self.action_save.triggered.connect(self.on_button_save_clicked)
        self.action_quit.triggered.connect(self.close)
        self.button_8.clicked.connect(self.close)
        self.JHBH_widget.hide() #隐藏几何变换的一对button
        
    def wheelEvent(self, event):
        if self.big_prev.pixmap() is None:  #big_prev无内容，无视滚轮
            print("None")
            return

        modifiers = QtWidgets.QApplication.keyboardModifiers()
        if modifiers != QtCore.Qt.ControlModifier:  #未按着ctrl滚轮，无视
            print('Ctrl 未按下')
            return

        self.delta = event.angleDelta().y()
        if self.big_prev.underMouse():   #big_prev是否在鼠标下面
            big_prev_height = self.big_prev.height()
            big_prev_width = self.big_prev.width()
            self.big_prev_pixmap = self.__no_scaled_big_prev_pixmap.copy()
            if(self.delta > 0):
                self.big_prev_scaled = self.big_prev_pixmap.scaled(big_prev_width*1.1, big_prev_height*1.1, aspectRatioMode=QtCore.Qt.KeepAspectRatio) 
                self.big_prev.setPixmap(self.big_prev_scaled)
                self.statusBar().showMessage("当前图片尺寸：" + str(big_prev_width) + ' X ' + str(big_prev_height))
                self.pub_thumb_prev()
            else:
                self.big_prev_scaled = self.big_prev_pixmap.scaled(big_prev_width*0.9, big_prev_height*0.9, aspectRatioMode=QtCore.Qt.KeepAspectRatio) 
                self.big_prev.setPixmap(self.big_prev_scaled)
                self.statusBar().showMessage("当前图片尺寸：" + str(big_prev_width) + ' X ' + str(big_prev_height))
                self.pub_thumb_prev()
        
       # print("鼠标位置", event.globalX(), "X",  event.globalY())
        
    def closeEvent(self, event): 
        #重写closeEvent,添加确认弹框
        if (isinstance(self.thumb_prev.pixmap(), QtGui.QPixmap)) is False:
            #sys.exit() 
            # 如果不用if嵌套,直接sys.exit()也可,但是if嵌套逻辑更清晰.
            # 如果self.img_prev.pixmap()不是Qpixmap,那么img_prev标签则没有图片,那么直接同意closeEvent退出即可.
            event.accept()
        else:
            checkMsgBox = QtWidgets.QMessageBox(self) 
            checkMsgBox.setWindowTitle("退出?") 
            checkMsgBox.setWindowIcon(QtGui.QIcon('./icons/quit.ico'))
            savequitButton = checkMsgBox.addButton(self.tr("保存&退出"), QtWidgets.QMessageBox.ActionRole)
            justquitButton = checkMsgBox.addButton(self.tr("直接退出"), QtWidgets.QMessageBox.ActionRole)
            cancelButton = checkMsgBox.addButton("手滑了,取消",QtWidgets.QMessageBox.ActionRole)
            checkMsgBox.setText(self.tr("对图片的修改还未保存,直接退出?"))
            checkMsgBox.exec_()
        
            button = checkMsgBox.clickedButton()
            if button == savequitButton:
                self.on_button_save_clicked()
                event.accept()
            elif button == justquitButton:
                event.accept()
            elif button == cancelButton:
                event.ignore()



    def gray(self, filename):
        im = Image.open(filename).convert('L')
        QtImage1 = ImageQt(im)
        pixmap = QtGui.QPixmap.fromImage(QtImage1)
        return pixmap
        #im.save('gray.jpeg')

    def erzhi(self, filename):
        im = Image.open(filename).convert('L').convert('1')
        QtImage1 = ImageQt(im)
        pixmap = QtGui.QPixmap.fromImage(QtImage1)
        return pixmap
        #im.save('erzhi.jpeg')

    def pub_thumb_prev(self):
        self.thumb_prev_pixmap = self.__no_scaled_big_prev_pixmap.copy()
        self.thumb_prev.setPixmap(self.thumb_prev_pixmap.scaled(self.thumb_prev.size(), aspectRatioMode=QtCore.Qt.KeepAspectRatio))
        print("prev已更改")

    def PIL_2_Qpixmap(self, pil_img):
        print("convert")

    @pyqtSlot()
    def on_action_about_triggered(self): 
        self.statusBar().showMessage('关于我们')   ###############################################################3
        QtWidgets.QMessageBox.information(None, "关于我们",
            "第X组\n")
    
    @pyqtSlot()
    def on_button_open_clicked(self):
    #    self.XZ_value = 0       #旋转角度初始化
    #    self.fileName = [None, '2']
        self.fileName = QtWidgets.QFileDialog.getOpenFileName(self,
		    "选择想要编辑的图片",
		    "./",
		    "常见图片格式(*.jpeg *.jpg *.png *.bmp) ;; 所有文件 (*)")
        print(self.fileName)
        self.statusBar().showMessage("已打开:" + self.fileName[0])
        self.__no_scaled_origin_pixmap = QtGui.QPixmap(self.fileName[0])
        self.__no_scaled_big_prev_pixmap = self.__no_scaled_origin_pixmap.copy()   
        self.big_prev.setPixmap(self.__no_scaled_origin_pixmap)
        self.thumb_origin.setPixmap(self.__no_scaled_origin_pixmap.copy().scaled(self.thumb_origin.size(), aspectRatioMode=QtCore.Qt.KeepAspectRatio))

      #  im = self.__no_scaled_origin_pixmap.scaled(self.img_origin.size(), aspectRatioMode=QtCore.Qt.KeepAspectRatio)
       # self.imgWidth, self.imgHight = im.width(), im.height()
       # self.unit = im.width()/200        
       # self.img_origin.setPixmap(im)
      #  self.__img_origin = im.copy()

    @pyqtSlot()
    def on_button_save_clicked(self):      
        QtWidgets.QMessageBox.information(None, "提示",
            "保存图片为右边预览窗口的图片,包括图片大小都是\n"
            "建议将图片缩放到所需尺寸后再保存\n")
        self.saveimg_name, self.saveimg_type = QtWidgets.QFileDialog.getSaveFileName(self,  
            "文件保存",
            "./",
            "Image files(*.jpeg *.jpg *.png *.bmp) ;; 所有文件 (*)")

        if self.saveimg_name != '':
            try:
                self.big_prev.pixmap().save(self.saveimg_name)
                self.statusBar().showMessage("已保存为:" + self.saveimg_name)
            except:
                self.statusBar().showMessage("保存失败")

    def on_slider_origin_valueChanged(self):
        value_now = (self.slider_origin.value()+1) * self.unit
        self.statusBar().showMessage("原图原尺寸：" + str(self.imgWidth) + "X" + str(self.imgHight) +
                          "\t原图当前尺寸：" + str(self.imgWidth - value_now) +
                          "X" + str(self.imgHight - value_now))
        im = QtGui.QPixmap(self.fileName[0]).scaled(self.imgWidth - value_now, self.imgHight - value_now, aspectRatioMode=QtCore.Qt.KeepAspectRatio)
        pixmap = im.transformed(QtGui.QTransform().rotate(self.XZ_value))

        self.img_origin.setPixmap(pixmap)
        
    def on_slider_prev_valueChanged(self):
        if 'prevDisplay' not in dir(self):
            self.prevDisplay = self.img_prev.pixmap().copy()    #保存预览图最初样貌,scaled会调用
            self.prevOrigin = self.prevDisplay.copy()
        else:
            self.prevDisplay = self.prevOrigin.copy()

        value_now = (self.slider_prev.value()+1) * self.unit
        self.statusBar().showMessage("预览图原尺寸：" + str(self.imgWidth) + "X" + str(self.imgHight) +
                          "\t预览图当前尺寸：" + str(self.imgWidth - value_now) +
                          "X" + str(self.imgHight - value_now))
        #缩放比例有点问题，待优化
        im = self.prevDisplay.scaled(self.imgWidth - value_now, self.imgHight - value_now, aspectRatioMode=QtCore.Qt.KeepAspectRatio)
        self.img_prev.setPixmap(im)


    @pyqtSlot()
    def on_button_1_clicked(self):
        self.gray(self.fileName[0])
        im = self.gray(self.fileName[0])
        self.img_prev.setPixmap(im)
        self.statusBar().showMessage("彩色图转灰度图完毕")


    @pyqtSlot()
    def on_button_2_clicked(self):
        self.setWindowTitle("灰->二")
        im = self.erzhi(self.fileName[0])
        self.img_prev.setPixmap(im)
        self.statusBar().showMessage("转换二值图完毕")

        
    @pyqtSlot()
    def on_button_3_clicked(self):

        if self.JHBH_widget.isHidden():
            self.JHBH_widget.show()
        #    self.statusBar().showMessage("几何变换，开关开启")
        else:
            self.JHBH_widget.hide()
       #     self.statusBar().showMessage("几何变换，开关关闭")


    def on_slider_PY_V_valueChanged(self):      #平移有问题######################################################
        self.statusBar().showMessage("水平平移")
        value_now = self.slider_PY_V.value() * 10
        pixmap = self.img_prev.pixmap()
        pixmap = self.qweqwe()
        print(type(pixmap))
        self.img_prev.setPixmap(pixmap)

    
    def qweqwe(self, xx=0, yx=0):
        im = Image.open("./lena.jpeg")
    #    im = Image.fromqpixmap(   )
    #    im = ImageChops.offset(im, xoffset=value_now, yoffset=0)
        QtImage1 = ImageQt(im)
        pixmap = QtGui.QPixmap.fromImage(QtImage1)
        return pixmap
        
        
    def on_slider_PY_S_valueChanged(self):
        self.statusBar().showMessage("垂直平移")
        value_now = self.slider_PY_S.value() * 10
        im = Image.fromqpixmap(self.img_prev.pixmap())
        im = ImageChops.offset(im, xoffset=0, yoffset=value_now)
        im = QtGui.QPixmap.fromImage(ImageQt(im))
        self.img_prev.setPixmap(im)

    @pyqtSlot()
    def on_JX_s_clicked(self):
        self.statusBar().showMessage("垂直镜像")
        pixmap = self.img_prev.pixmap().toImage().mirrored(True, False) #两个参数,前者为X轴,后者Y轴.控制是否镜像
        pixmap = QtGui.QPixmap.fromImage(pixmap)
        self.img_prev.setPixmap(pixmap)

    @pyqtSlot()
    def on_JX_v_clicked(self):
        self.statusBar().showMessage("水平镜像")
        pixmap = self.img_prev.pixmap().transformed(QtGui.QTransform().rotate(180)) #旋转180度
        self.img_prev.setPixmap(pixmap)


    def on_slider_XZZZZ_valueChanged(self):
        try:
            value_old = value_now
        except:
            value_old = 0
    
        value_now = ( self.slider_XZ.value() + 1 ) - value_old
        self.XZ_value = value_now
        self.statusBar().showMessage(str(value_now))

        transform = QtGui.QTransform()
        transform.rotate(value_now)
        
        pixmap = self.img_origin.pixmap().transformed(value_now)
        self.img_origin.setPixmap(pixmap)

    def on_slider_XZ_valueChanged(self):
        
        if 'originXZOrigin' not in dir(self):
            self.originXZOrigin = self.img_origin.pixmap().copy()    #保存预览图最初样貌,scaled会调用
            self.prevXZ2Origin = self.originXZOrigin.copy()
        else:
            self.originXZOrigin = self.prevXZ2Origin.copy()

        
        value_now = self.slider_XZ.value() * 3.6
        pixmap = Image.fromqpixmap(self.originXZOrigin)
        pixmap = pixmap.rotate(value_now) #两
        QtImage1 = ImageQt(pixmap.convert('RGBA'))
        pixmap = QtGui.QPixmap.fromImage(QtImage1)
        self.img_origin.setPixmap(pixmap)
       



        
    def on_slider_XZQTTT_valueChanged(self):
        transform = QtGui.QTransform()
        centerX = 50
        centerY = 50
        transform.translate( centerX , centerY  )
        transform.rotate( 180 )
        self.img_origin.setTransform( transform )
       # self.img_origin.setPixmap(pixmap)

        
    @pyqtSlot()
    def on_button_4_clicked(self):
        self.statusBar().showMessage("去噪 按钮按下")

    @pyqtSlot()
    def on_button_5_clicked(self):
        pass
        #测试图片实时缩放
       # self.statusBar().showMessage("push 按钮按下")
       # self.setWindowTitle("push")

    @pyqtSlot()
    def on_button_6_clicked(self):
        self.statusBar().showMessage("边缘提取 按钮按下")

    @pyqtSlot()
    def on_button_7_clicked(self):
        self.statusBar().showMessage("加躁 按钮按下")



if __name__ == "__main__":
    app=0
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec_())


